CREATE DATABASE ecommerce;
USE ecommerce;
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    country VARCHAR(50)
);
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    total_amount DECIMAL(10, 2),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);
CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10, 2),
    stock_quantity INT
);
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    subtotal DECIMAL(10, 2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

INSERT INTO customers VALUES
(1, 'Ravi', 'Kumar', 'ravi.kumar@example.com', 'India'),
(2, 'Priya', 'Sharma', 'priya.sharma@example.com', 'India'),
(3, 'John', 'Smith', 'john.smith@example.com', 'USA'),
(4, 'Sara', 'Lee', 'sara.lee@example.com', 'UK'),
(5, 'David', 'Brown', 'david.brown@example.com', 'Australia');

INSERT INTO products VALUES
(101, 'Laptop', 'Electronics', 75000.00, 10),
(102, 'Smartphone', 'Electronics', 35000.00, 20),
(103, 'Headphones', 'Accessories', 2500.00, 50),
(104, 'Office Chair', 'Furniture', 8000.00, 15),
(105, 'Wrist Watch', 'Accessories', 5000.00, 30);

INSERT INTO orders VALUES
(1001, 1, '2025-08-01', 110000.00),
(1002, 2, '2025-08-02', 35000.00),
(1003, 3, '2025-08-03', 5000.00),
(1004, 1, '2025-08-04', 8000.00),
(1005, 4, '2025-08-05', 2500.00);

INSERT INTO order_items VALUES
(1, 1001, 101, 1, 75000.00),
(2, 1001, 102, 1, 35000.00),
(3, 1002, 102, 1, 35000.00),
(4, 1003, 105, 1, 5000.00),
(5, 1004, 104, 1, 8000.00),
(6, 1005, 103, 1, 2500.00);


select customer_id from customers;

SELECT customer_id, first_name, last_name, country
FROM customers WHERE country = 'India' ORDER BY last_name ASC;

SELECT c.country, SUM(o.total_amount) AS total_sales
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.country
ORDER BY total_sales DESC;

SELECT o.order_id, CONCAT(c.first_name, ' ', c.last_name) AS customer_name, o.total_amount
FROM orders o
INNER JOIN customers c ON o.customer_id = c.customer_id
ORDER BY o.total_amount DESC;

SELECT p.product_name, SUM(oi.quantity) AS total_sold
FROM products p
LEFT JOIN order_items oi ON p.product_id = oi.product_id
GROUP BY p.product_name
ORDER BY total_sold DESC;

SELECT customer_id, first_name, last_name
FROM customers
WHERE customer_id IN (
    SELECT customer_id
    FROM orders
    GROUP BY customer_id
    HAVING SUM(total_amount) > (
        SELECT AVG(total_amount) FROM orders
    )
);

CREATE VIEW monthly_sales AS
SELECT DATE_FORMAT(order_date, '%Y-%m') AS month,
       SUM(total_amount) AS total_sales,
       COUNT(order_id) AS total_orders
FROM orders
GROUP BY DATE_FORMAT(order_date, '%Y-%m');



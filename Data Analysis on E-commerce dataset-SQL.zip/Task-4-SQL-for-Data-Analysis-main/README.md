# Task-4-SQL-for-Data-Analysis
# SQL for Data Analysis – Ecommerce Dataset

This project showcases SQL skills using a sample Ecommerce database with tables for customers, orders, products, and order items.  
It demonstrates data extraction, aggregation, and optimization techniques in MySQL/PostgreSQL/SQLite.

## Features
- SELECT, WHERE, ORDER BY, GROUP BY
- INNER & LEFT JOINs
- Aggregate functions (SUM, AVG, COUNT)
- Subqueries
- Views for monthly sales analysis
- Indexing for performance

## How to Use
1. Run `ecommerce.sql` to create tables and insert sample data.
2. Execute queries in `task4_queries.sql` to perform analysis.
3. View results in your SQL editor and take screenshots.

Example Monthly Sales Output:
| month   | total_sales | total_orders |
|---------|-------------|--------------|
| 2025-08 | 160500.00   | 5            |

